<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="copyright text-center my-auto">
            <span>copyright &copy;
                <script>
                    document.write(new Date().getFullYear());
                </script> - developed by
                <b><a href="" target="_blank">team</a></b>
            </span>
        </div>
    </div>
</footer>